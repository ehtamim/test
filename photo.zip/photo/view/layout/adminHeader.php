<!DOCTYPE html>
<head><link rel="stylesheet" type="text/css" href="../css/mycss.css"></head>
<body>
    <div>
    <h2 class="header">PHOTO GALERY</h2>
</div>
<div class="topnav">
  <a class="active" href="adminDashboard.Php">Dashboard</a>
  <a href="addPhoto.php">Add Photo</a>
  <a href="category.php">Categories</a>
  <a href="alluser.php">All User</a>
  <a href="insertUser.php">Add User</a>
  <a href="systemOrders.php">View Orders</a>
  <div id="right">
  <a href="../control/logout.php">Logout</a>
</div>
</div>
</body>
</html>