<!DOCTYPE html>
<head><link rel="stylesheet" type="text/css" href="../css/mycss.css"></head>
<body>
<div class="topnav">
  <a class="active" href="usersDashboard.Php">Dashboard</a>
  <a href="viewAllPhotos.php">All Photo</a>
  <a href="userFavourites.php">My Favourites</a>
  <a href="../control/logout.php">Logout</a>
</div>
</body>
</html>