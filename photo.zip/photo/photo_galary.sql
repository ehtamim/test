-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2023 at 07:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photo_galary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `status`) VALUES
(1, 'emam', 'ee35141d2ff1de1401ed706801541ea1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `photo_id`, `user_id`) VALUES
(1, 4, 1),
(2, 13, 1),
(3, 22, 1),
(4, 20, 1),
(5, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Flower'),
(2, 'Car'),
(3, 'Animal'),
(4, 'Bird'),
(6, 'Nature'),
(7, 'Hill'),
(9, 'Vehicles'),
(10, 'Bicycle'),
(11, 'Forest'),
(12, 'House');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `total` double NOT NULL,
  `payment` tinyint(4) NOT NULL,
  `delivery` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `total`, `payment`, `delivery`) VALUES
(1, 600, 1, 0),
(2, 100, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_photo`
--

CREATE TABLE `order_photo` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_photo`
--

INSERT INTO `order_photo` (`id`, `order_id`, `photo_id`, `quantity`) VALUES
(1, 1, 21, 3),
(2, 1, 20, 3),
(3, 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_user`
--

CREATE TABLE `order_user` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_user`
--

INSERT INTO `order_user` (`id`, `order_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `location` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `name`, `description`, `status`, `location`, `price`, `quantity`) VALUES
(1, 'Rose', 'This Blue rose is very beautiful.', 1, 'blue_flower.jpg', 50, 13),
(2, 'Lion', 'Lion is the king of all animals.', 1, 'lion.jpg', 60, 10),
(3, 'Robin', 'Robin is a very beautiful bird.', 1, 'robin_bird.jpg', 40, 10),
(4, 'Red Car', 'This is a red car.', 1, 'red_car.jpg', 100, 20),
(5, 'Hill', 'The picture shows a very beautiful hill.', 1, 'hill.jpg', 25, 8),
(7, 'Field', 'This picture shows a very beautiful green field.', 1, 'green_field.jpg', 45, 15),
(13, 'Bicycle', 'A natural scenery of a man setting by a bicycle.', 1, 'bicycle.jpg', 20, 45),
(14, 'Hills', 'A green view of hills.', 1, 'hill_green.jpg', 15, 10),
(15, 'Car in Forest', 'A car in a beautiful forest.', 1, 'car_image.jpg', 30, 20),
(16, 'Zebra', 'Each zebra has its own unique pattern of distinctive stripes.', 1, 'zebra.png', 40, 5),
(17, 'House in forest', 'A house in nature.', 1, 'main-wyoming.jpg', 70, 3),
(18, 'Tiger', 'Tiger is a very precious animal for Bangladesh.', 1, 'tiger.jpg', 62, 6),
(19, 'Elephant', 'The Elephant is a very big animal.', 0, 'elephent.jpg', 130, 10),
(20, 'Water Lily', 'A water lily looks very nice.', 1, 'pink_flower.jpg', 75, 5),
(21, 'Peacock', 'The feather of a peacock is very attractive.', 1, 'peacock_bird.jpg', 125, 2),
(22, 'Black Car', 'This black car looks like a beast.', 1, 'black_car.jpg', 100, 15),
(23, 'House', 'A beautiful house in nature.', 1, 'hooooouss.jpg', 200, 6),
(24, 'Forest', 'Two people walking in a forest.', 1, 'human_in_forest.jpg', 60, 18),
(25, 'Green Forest', 'An amazing view of a green forest.', 1, 'forest.jpg', 45, 3);

-- --------------------------------------------------------

--
-- Table structure for table `photo_category`
--

CREATE TABLE `photo_category` (
  `id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `photo_category`
--

INSERT INTO `photo_category` (`id`, `photo_id`, `category_id`) VALUES
(53, 25, 6),
(54, 25, 11),
(56, 1, 1),
(57, 4, 2),
(58, 4, 9),
(59, 13, 6),
(60, 13, 9),
(61, 13, 10),
(62, 3, 4),
(63, 2, 3),
(64, 5, 6),
(65, 7, 6),
(66, 14, 6),
(67, 14, 7),
(68, 15, 2),
(69, 15, 6),
(70, 15, 9),
(71, 15, 11),
(72, 22, 2),
(73, 22, 9),
(74, 21, 4),
(75, 21, 6),
(76, 18, 3),
(77, 16, 3),
(78, 17, 6),
(79, 17, 11),
(80, 17, 12),
(81, 19, 3),
(84, 23, 6),
(85, 23, 11),
(86, 23, 12),
(87, 24, 6),
(88, 24, 11),
(89, 20, 1),
(90, 20, 6);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `email`, `status`) VALUES
(1, 'Abc Mno', 'abc', '87f0ec7f6ef13ca439367bd41f3d1117', 'abc@gmail.com', 1),
(2, 'Mr Xyz', 'xyz', '93f502e9bfba99426ade91dc82e724eb', 'xyz@yahoo.com', 1),
(3, 'Mr Doe', 'doe', '1f013789a800bcf0f5fdb04644801b5a', 'doe@gmail.com', 0),
(4, 'Mr Tom', 'tom', '57a588fdf684fdceee0d1cc77592ac95', 'tom@email.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_fav`
--

CREATE TABLE `user_fav` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_fav`
--

INSERT INTO `user_fav` (`id`, `user_id`, `photo_id`) VALUES
(1, 1, 3),
(2, 2, 3),
(3, 2, 7),
(5, 1, 18),
(6, 1, 13),
(7, 1, 14),
(8, 1, 1),
(9, 1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `user_rating`
--

CREATE TABLE `user_rating` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_rating`
--

INSERT INTO `user_rating` (`id`, `user_id`, `photo_id`, `rating`) VALUES
(1, 1, 2, 4),
(2, 2, 4, 5),
(3, 1, 18, 4),
(6, 1, 4, 5),
(7, 1, 14, 5),
(9, 1, 20, 3),
(10, 1, 1, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_photo`
--
ALTER TABLE `order_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_user`
--
ALTER TABLE `order_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photo_category`
--
ALTER TABLE `photo_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_fav`
--
ALTER TABLE `user_fav`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_rating`
--
ALTER TABLE `user_rating`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_photo`
--
ALTER TABLE `order_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_user`
--
ALTER TABLE `order_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `photo_category`
--
ALTER TABLE `photo_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_fav`
--
ALTER TABLE `user_fav`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_rating`
--
ALTER TABLE `user_rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
