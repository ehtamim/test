
<?php $__env->startSection('tilte'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apwt-mid\resources\views/homepage.blade.php ENDPATH**/ ?>