<html>
    <title>Home
</title>
<body>
    <h1> This is home page. </h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\wtlab2\resources\views/homepage.blade.php ENDPATH**/ ?>