@extends('layouts.app')
@section('tilte')
Home
@endsection
@section('content') 
@endsection