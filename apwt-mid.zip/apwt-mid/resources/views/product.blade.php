<!DOCTYPE html>
<html>
<body onload="loadDoc()">

<h2>Product Details</h2>

<p id="productName"></p>
<p id="productCode"></p>
<p id="productManu"></p>
<p id="productExp"></p>

<script>
    function loadDoc() 
    {
        
    }
</script>

<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
Click me to display Date and Time.</button>

<p id="demo"></p>

</body>
</html> 
