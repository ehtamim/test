<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
<!-- <link href="css/mycss.css" rel="stylesheet" type="text/css"> -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="active"><a href="/home">Home</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="/logout"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
    </ul>
  </div>
</nav>    
<h1> WELCOME TO OUR WEBSITE </h1>
    <h2>Employee Dashboard</h2> <br>

    <a href="/profile"> <input name="profile" type="submit" value="PROFILE"> </a>
    <br> <br>

    <a href="services.php"> <input name="services" type="submit" id="click" value="SERVICES"> </a>
    <br> <br>
    <a href="travelinfo.php"> <input name="travelinfo" type="submit" id="click" value="UPDATE INFORMATION">
    </a>
    <br> <br>
    </div>
</body>

</html>
