<?php

namespace App\Http\Controllers;
use App\Models\product;
use Illuminate\Http\Request;

class productController extends Controller
{
    public function Apilist()
    {
        return product::all();
    }

    public function createProduct(Request $req)
    {
        $product=new product();
        $product->productName=$req->name;
        $product->productCode=$req->code;
        $product->productManu=$req->mdate;
        $product->productExp=$req->edate;
        $product->save();
    }

}
