<html>
    <title>Register</title>
<body>
<h1>Registration</h1>
<form action="/register" method="post">
<?php echo e(csrf_field()); ?>

Your username is <input type="text" name="username">
<?php if($errors->has('username')): ?>
<b><?php echo e($errors->first('username')); ?></b>
<?php endif; ?>
<br><br>
Your email is <input type="text" name="email" value="">
<?php if($errors->has('email')): ?>
<b><?php echo e($errors->first('email')); ?></b>
<?php endif; ?>
<br><br>
Your Date of birth is <input type="date" name="dob" value="">
<?php if($errors->has('dob')): ?>
<b><?php echo e($errors->first('dob')); ?></b>
<?php endif; ?>
<br><br>
Language Preference
<input type="checkbox" id="lan1" name="lan"> Bangla 
<input type="checkbox" id="lan2" name="lan"> English
<?php if($errors->has('lan')): ?>
<b><?php echo e($errors->first('lan')); ?></b>
<?php endif; ?>
<br><br>
Your file is <input type="file" name="file" value=" ">
<?php if($errors->has('file')): ?>
<b><?php echo e($errors->first('file')); ?></b>
<?php endif; ?>
<br><br>

<input type="submit" value="Register"> <br> <br><br>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\wtlab2\resources\views/register.blade.php ENDPATH**/ ?>